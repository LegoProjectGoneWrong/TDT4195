#pragma once

#include <math.h>
#include "SceneGraph.hpp"

unsigned int createCircleVAO(unsigned int slices, unsigned int layers);