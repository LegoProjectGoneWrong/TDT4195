// Local headers
#include "program.hpp"
#include "gloom/gloom.hpp"
#include "gloom/shader.hpp"

unsigned int setupVBO(float* vertices, int nVertices,int* indices,int nIndices){
    //Creates and binds VAO, referenced in array
    unsigned int array = 0;
    glGenVertexArrays(1,&array);
    glBindVertexArray(array);

    //creates buffer and binds it
    GLuint bufferIDs = 0;
    glGenBuffers(1,&bufferIDs);
    glBindBuffer(GL_ARRAY_BUFFER,bufferIDs);

    //Finds vertice lengthm and pushes the data to the buffer
    size_t vertices_len = nVertices*sizeof(float);
    glBufferData(GL_ARRAY_BUFFER,vertices_len,vertices,GL_STATIC_DRAW); 

    //sets Vertext Attribute Pointer and enables the VBO
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,0,0);
    glEnableVertexAttribArray(0);
    
    //creates the Index Buffer
    GLuint bufferID_indices = 0;
    glGenBuffers(1,&bufferID_indices);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,bufferID_indices);
    size_t indice_len = nIndices*sizeof(int);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,indice_len,indices,GL_STATIC_DRAW);

    return array;
}


void runProgram(GLFWwindow* window)
{
    // Set GLFW callback mechanism(s)
    glfwSetKeyCallback(window, keyboardCallback);

    // Enable depth (Z) buffer (accept "closest" fragment)
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    // Configure miscellaneous OpenGL settings
    glEnable(GL_CULL_FACE);

    // Set default colour after clearing the colour buffer
    glClearColor(0.3f, 0.3f, 0.4f, 1.0f);

    // TO DO
    // Set up your scene here (create Vertex Array Objects, etc.)
    //void glGenVertexArrays(int count, unsigned int* arrayIDs)

    
    int vertices_lenA = 75;
    float verticesA[75];
    int i=0;
    //creates a 25*25 matrix, top right is index 0, top left is 5 and bottom right is 24
    for (float y =1; y>=-1; y-=0.5){
      for (float x =-1;x <=1;x+=0.5){
        verticesA[i]=x;
        verticesA[i+1]=y;
        verticesA[i+2]=0;
        i+=3;
      }
    };
    //The indices used in task b
    int indices_lenA = 15;
    int indicesA[] = {
      0,10,2,
      2,14,4,
      10,20,22,
      22,24,14,
      11,13,7 //invert this to 7,13,11 for the no triangle
    };
    //the vertices and indices used in task d
    int vertices_lenB = 9;
    float verticesB[]={
      0.6,-0.8,-1.2,
      0.0,0.4,0,
      -0.8,-0.2,1.2
    };
    int indices_lenB = 3;
    int indicesB[] = {0,1,2};
    
    //used to quickly edit the setupVBO parameters
    float* vertices = verticesA;
    int vertices_len = vertices_lenA;
    int* indices = indicesA;
    int indices_len = indices_lenA;
    
    unsigned int array = setupVBO(vertices,vertices_len,indices,indices_len);
    
    //enables the shaders
    Gloom::Shader shader;
    shader.makeBasicShader("../gloom/shaders/simple.vert","../gloom/shaders/simple.frag"); 

    shader.activate();
    // Rendering Loop
    while (!glfwWindowShouldClose(window))
    {
        // Clear colour and depth buffers
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        // Draw your scene here DO THIS
        //Binds array and draws the scene
        glBindVertexArray(array);

        glDrawElements(GL_TRIANGLES,indices_len,GL_UNSIGNED_INT,0);

        // Handle other events
        glfwPollEvents();

        // Flip buffers
        glfwSwapBuffers(window);
    }
    shader.deactivate();
}


void keyboardCallback(GLFWwindow* window, int key, int scancode,
                      int action, int mods)
{
    // Use escape key for terminating the GLFW window
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, GL_TRUE);
    }
}
